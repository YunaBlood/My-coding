<?php

require 'Cercle.php';
require 'Point2.php';

$cercle = new Cercle;
$point = new Point(5.2, 2.5);

var_dump($cercle, $point);