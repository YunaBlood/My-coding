<!-- Définir une classe Livre avec les attributs suivants : Titre, Auteur (Nom complet), Prix.
Définir à l’aide des propriétés les méthodes d’accès aux différents attributs de la classe.
Définir un constructeur permettant d’initialiser les attributs de la méthode par des valeurs saisies par l’utilisateur.
Définir la méthode Afficher ( ) permettant d’afficher les informations du livre en cours.
Écrire un programme testant la classe Livre. -->

<?php 

class Livre {
    private $titre;
    private $auteur;
    private $prix;


    public function __construct(String $titre, String $auteur, Float $prix){
        $this->titre = $titre;
        $this->auteur = $auteur;
        $this->prix = $prix;
    }


    public function getTitre(){
        return $this->titre;
    }

    public function getAuteur(){
        return $this->auteur;
    }

    public function getPrix(){
        return $this->prix;
    }

    public function setTitre(String $titre){
        $this->titre = $titre;
    }

    public function setAuteur(String $auteur){
        $this->auteur = $auteur;
    }

    public function setPrix(Float $prix){
        $this->prix = $prix;
    }

    public function affichage(){
        echo "Voici le titre du livre : ".$this->titre .' <br>';
        echo "Voici l'auteur du livre : ". $this->auteur. '<br>';
        echo "Voici le prix du livre : ". $this->prix; 
    }


}

if(class_exists('Livre')){
    echo "Ok". '<br>';
}else{
    echo "Pas de classe";
}