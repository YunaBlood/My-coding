<?php

require 'Rectangle.php';

$rectangle = new Rectangle(10, 5);

$rectangle->afficherRectangle();

var_dump($rectangle);