<?php

require 'Livre.php';

$book = new Livre('Docteur Sleep', 'Stephen King', 8.90);

$book->affichage();

var_dump($book);

