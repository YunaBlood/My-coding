<?php 

require 'Point.php';

$point = new Point(1, 3);

$point->norme();

var_dump($point);
