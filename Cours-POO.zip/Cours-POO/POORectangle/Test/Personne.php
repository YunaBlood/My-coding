<?php

class Personne {
    public $nom;
    public $prenom;

    public function __construct(string $nom, string $prenom){
        $this->nom = $nom;
        $this->prenom = $prenom;
    }
}