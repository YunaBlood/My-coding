<?php
class Compte {
    private $num_compte;
    private $solde;
    public $personne;

    public function __construct(string $num_compte, float $solde, Personne $personne){
        $this->num_compte = $num_compte;
        $this->solde = $solde;
        $this->personne = $personne;
    }

    public function credit(Compte $compte, int $somme){
        $compte->solde += $somme;
        $this->solde -= $somme;
    }

    public function AfficherSolde(){
        // var_dump($this->personne);
        // die();
        echo "Le solde de {$this->personne->prenom} est de : {$this->solde}"; 
    }
}