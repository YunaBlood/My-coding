<?php

require 'Personne.php';
require 'Compte.php';



$michou = new Personne ('Dupont', 'Michou');
$compteMich = new Compte ('J8FH2', 500, $michou);
$brigitte = new Personne('Doe', 'Brigitte');
$compte = new Compte('AE458', 1000, $brigitte);


// echo "Bonjour je suis {$compte->personne}";

$compte->credit($compteMich, 200);

$compte->AfficherSolde();
echo "<br>";
$compteMich->AfficherSolde();

var_dump($compte);