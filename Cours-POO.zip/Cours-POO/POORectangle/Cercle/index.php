<?php 

require 'Point.php';
require 'Cercle.php';

$point = new Point(1.2, 3.3);
$cercle = new Cercle(5.2, 3.2);

$point->setY(6);
$point->setX(4);

var_dump($point);