<!-- Définir une classe Rectangle ayant les attributs suivants : Longueur et Largeur.
Définir à l’aide des propriétés les méthodes d’accès aux attributs de la classe.
Ajouter un constructeur d’initialisation.
Ajouter les méthodes suivantes :
Périmètre ( ) : retourne le périmètre du rectangle.
Aire( ) : retourne l'aire du rectangle.
EstCarre( ) : vérifie si le rectangle est un carré.
AfficherRectangle( ) : expose les caractéristiques d’un rectangle comme suit :
Longueur : […] - Largeur : […] - Périmètre : […] - Aire : […] - Il s’agit d’un carré / Il ne s’agit pas d’un carré -->

<?php

class Rectangle {
    private $longueur;
    private $largeur;

    public function __construct(int $largeur = null, int $longueur = null){
        $this->largeur = $largeur;
        $this->longueur = $longueur;
    }

    public function get_longueur(){
        return $this->$longueur;
    }
    
    public function get_largeur(){
        return $this->largeur;
    }

    public function setLongueur(int $value){
        $this->longueur = $value;
    }

    public function setLargeur(int $value){
        $this->largeur = $value;
    }

    public function EstCarre(){
        if($this->largeur === $this->longueur){
            return true;
        }

        return false;
    }

    public function Perimetre(){
        $perimetre = ($this->longueur)+($this->largeur)*2;
        return $perimetre;
    }

    public function Aire(){
        $aire = ($this->longueur*$this->largeur);
        return $aire;
    }

    public function Afficher(){
        echo "Longueur : ". $this->longueur;
        echo "<br> Largeur : ". $this->largeur;
        echo "<br>Perimetre : ". $this->Perimetre();
        echo "<br>Aire : ". $this->Aire();
        echo $this->estCarre() ? ' <br> Le rectangle est carré' : '<br> Le rectangle n\'est pas carré';
    }
}