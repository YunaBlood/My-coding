<?php

require 'Rectangle.php';
require 'Personne.php';
require 'Compte.php';

$rect = new Rectangle;
$rectangle = new Rectangle(10,10);

$rect->setLargeur(6);
$rect->setLongueur(4);


$rectangle->Afficher();

var_dump($rectangle);

$brigitte = new Personne('Doe', 'Brigitte')
$compte = new Compte('AE458', 1000, )

var_dump($compte);