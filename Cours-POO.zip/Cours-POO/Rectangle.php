<!-- Définir une classe Rectangle ayant les attributs suivants : Longueur et Largeur.
Définir à l’aide des propriétés les méthodes d’accès aux attributs de la classe.
Ajouter un constructeur d’initialisation.
Ajouter les méthodes suivantes :
Périmètre ( ) : retourne le périmètre du rectangle.
Aire( ) : retourne l'aire du rectangle.
EstCarre( ) : vérifie si le rectangle est un carré.
AfficherRectangle( ) : expose les caractéristiques d’un rectangle comme suit :
Longueur : […] - Largeur : […] - Périmètre : […] - Aire : […] - Il s’agit d’un carré / Il ne s’agit pas d’un carré -->

<?php

class Rectangle{
    private $longueur = 10;
    private $largeur = 5;

    public function __construct(int $longueur, int $largeur){
        $this->longueur = $longueur;
        $this->largeur = $largeur;
    }

    public function getLongueur(){
        return $this->longueur;
    }

    public function getLargeur(){
        return $this->largeur;
    }

    public function setLongueur(int $longueur){
        $this->longueur = $longueur;
    }

    public function setLargeur(int $largeur){
        $this->largeur = $largeur;
    }

    public function perimetre(){
        $perimetre = ($this->longueur+$this->largeur)*2;
        return $perimetre;
    }

    public function aire(){
        $aire = ($this->longueur*$this->largeur);
        return $aire;
    }

    public function estCarre(){
        $carre = ($this->longueur === $this->largeur);
        return $carre;
    }
    public function afficherRectangle(){
        echo "Longueur : ". $this->longueur;
        echo "<br> Largeur : ". $this->largeur;
        echo "<br>perimetre : ". $this->perimetre();
        echo "<br>aire : ". $this->aire();
        echo $this->estCarre() ? ' <br> Le rectangle est carré' : '<br> Le rectangle n\'est pas carré';
    }
}