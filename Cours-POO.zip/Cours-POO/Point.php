<!-- Définir une classe Point caractérisée par son abscisse et son ordonné.
Définir à l’aide des getters et les setters les méthodes d’accès aux attributs de la classe.
Définir le constructeur par défaut et d’initialisation de la classe.
Définir la méthode Norme ( ) qui retourne la distance entre l’origine du repère et le point en cours.
Écrire un programme permettant de tester la classe. -->

<?php

class Point{
    private $abscisse = 1;
    private $ordonne = 3;

    public function __construct(int $abscisse, int $ordonne){
        $this->abscisse = $abscisse;
        $this->ordonne = $ordonne;
    }


    public function getAbscisse(){
        return $this->abscisse;
    }

    public function getOrdonne(){
        return $this->ordonne;
    }

    public function setAbscisse(int $abscisse){
        $this->abscisse = $abscisse;
    }

    public function setOrdonne(int $ordonne){
        $this->ordonne = $ordonne;
    }

    public function norme(){
    $somme = pow($this->abscisse, 2) + pow($this->ordonne, 2);
    
    echo 'La Norme est de '.sqrt($somme);

    }

}

if(class_exists('Point')){
    echo "La classe Point existe bien ! ". '<br>';
}else{
    echo "La classe Point n'existe pas";
}