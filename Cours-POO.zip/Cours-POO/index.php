<?php

require 'Personnage.php';

$link = new Personnage('Link');

$zelda = new Personnage('Zelda');

$zelda->setVie(150);
// Utiliser la méthode pour donner 50 point de vie à Zelda
echo "Les point de vie de Zelda sont de ". $zelda->getVie();

var_dump($link, $zelda);