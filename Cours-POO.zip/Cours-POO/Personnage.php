<?php

class Personnage {
    private $vie = 100;
    private $nom;
    private $atk = 10;

    public function __construct(String $nom){
            $this->nom = $nom;

    }

    public function getVie(){
        return $this->vie;
    }

    // Créer une méthode qui permet de modifier la vie d'un personnage

    public function setVie(int $vie){
        $this->vie = $vie;
    }

}