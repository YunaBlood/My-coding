<?php

// Exercice 1 : Une fonction qui permet de chercher un élément dans un tableau qui retournera l'index de celui-ci si il existe sinon false. Ensuite je veux que vous trouviez l'équivalent en fonction PHP et JavaScript avec un exemple pour chaque




//Exercice 1 fait en if et utilisant array_search

// function index($A){
//     $tableau = array ('Daniel','Valentin','Lucie','Mathilde');
//     $pos = array_search ($A,$tableau);
//     if($pos!==false){
//         echo 'Trouvé en position '.$pos.'<br>';
//     }else{
//         echo "pas trouvé <br>";
//     }
    
// }

// index('Mathilde');


//Exercice 1 fait en for 
$tab = [1,2,3,4,5];

function search(Array $array, $element){
    for($i = 0;$i < count($array);$i++){
        if($element === $array[$i]){
           return $i; //return retourne l'index de l'élément rechercher
        }
    }

    return false;
}

$result = search($tab, 1);
$result2 = search($tab, 2);
$result3 = search($tab, 3);

var_dump($result, $result2, $result3);


// Exercice 2 : Une fonction qui permet de trier un tableau dans l'ordre croissant qui retourne ce tableau trier. Ensuite je veux que vous trouviez l'équivalent en fonction PHP et JavaScript avec un exemple pour chaque

