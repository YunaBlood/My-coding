<?php

// Une fonction qui permet de trier un tableau dans l'ordre croissant qui retourne ce tableau trier. Ensuite je veux que vous trouviez l'équivalent en fonction PHP et JavaScript avec un exemple pour chaque

$tab = [2,9,6,1,4];

function triAbulle(Array $array){

    for($j = 0;$j < count($array) - 1;$i++){
        for($i = 0;$i < count($array) - 1; $i++){
            if($array[$i] > $array[$i + 1]){
                $temp = $array[$i];
                $array[$i] = $array[$i + 1];
                $array[$i + 1] = $temp;
            }
        }
    }

    return $array;
}

// l'équivalent a notre fonction triAbulle() en php est sort()

$result = triAbulle($tab);

var_dump($result);