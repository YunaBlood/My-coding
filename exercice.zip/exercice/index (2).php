<?php
// Exercice VI :Calculer le PGCD (Plus Grand Commun Dénominateur) de deux nombres entiers saisie au clavier.

// $nombre1 = 30;
// $nombre2 = 20;
// $pgcd = 0;


// while($nombre1 != $nombre2){
//     $pgcd = $nombre1 % $nombre2;
// };

// echo "Le PGCD est de $pgcd";

// $a = 10;
// $b = 3;
// $r = 0;


// Si a est différent de 0 et b différent de 0 et que a supérieur à b
// if($a !== 0 && $b!== 0 && $a > $b){
//     $r = $a % $b;
//     while($r !== 0){
//         $a = $b;
//         $b = $r;
//         $r = $a % $b;
//     }
//     $pgcd = $b;

// }

// echo "Le pgcd de $a et $b vaut : $pgcd <br>";



//Lire la somme qu’il paye, et simuler la remise de la monnaie en affichant les textes "10 Euros", "5 Euros" et "1 Euro" autant de fois qu’il ya de coupures de chaque sorte à rendre.

// $montantApayer = 27;
// $SommeRecu = 50;
// $monnaie = 30;
// $nbBillet10 = 0;
// $nbBillet5 = 0;
// $nbPiece2 = 0;
// $nbPiece1 = 0;


// if($SommeRecu > $montantApayer){
//     $monnaie = $SommeRecu - $montantApayer;
// }
// while($monnaie){
//     if($monnaie >= 10){
//         $nbBillet10++;
//         $monnaie -= 10;
//     }elseif($monnaie >= 5){
//         $nbBillet5++;
//         $monnaie -= 5;
//     }elseif($monnaie >= 2 ){
//         $nbPiece2++;
//         $monnaie -= 2;
//     }else{
//         $nbPiece1++;
//         $monnaie -= 1;
//     }
        
//     }

// echo "La monnaie rendu sera de <br> de Billet de 10 : $nbBillet10 <br> de Billet de 5 : $nbBillet5 <br> de Pieces de 2 : $nbPiece2 <br> de Pieces de 1 : $nbPiece1 <br>";


// // EXERCICE1
// 1°) Écrire une boucle qui produit une ligne horizontale de 8 étoiles
// 2°) Å partir de l’exercice précédent créer une fonction ​ligne​ ​qui permet de créer une ligne de ​n​ étoiles, ​n​ étant le paramètre de la fonction.
// 3°) Imbriquer la fonction précédente dans une boucle pour créer un carré. Puis créer une fonction square​ qui permettra de créer un carré.
// 4°) Produire des triangles rectangles sous différentes orientations, envisagez les vide ou plein.




function square($carre){
    for($i = 0;$i < $carre;$i++){
        ligne($carre);
        echo "<br>";

    }
}


function ligne($n){
    $string = '';

    for($i = 0;$i < $n;$i++){
        $string = $string . 'X';
    
    }
    echo $string;
}

// ligne(6);
// echo "<br>";
// ligne(6);
// echo "<br>";
// ligne(6);
// echo "<br>";
// ligne(6);

function triangle($t){
    $string = '';

    for($i = 1;$i < $t;$i++){
        ligne($i);
        echo "<br>";
    }
}

triangle(20);

// function somme($a, $b){
//     $somme = $a + $b;
//     echo " La somme de $a + $b vaut : $somme";
// }

// somme(4, 6);
// echo "<br>";
// somme(10, 180);
// echo "<br>";
// somme(8, -10);

