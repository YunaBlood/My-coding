<?php

// Exercice 3 : Une fonction min qui retournera la valeur minimal d'un tableau d'entier. Ensuite je veux trouviez l'équivalent en fonction PHP et JavaScript si elle existe avec un exemple pour chaque

// $tab = [10,20,30,423,5];

// function mini(Array $array){
//     $mini = $array[0];
//     for($i = 0;$i < count($array);$i++){
//         if($mini > $array[$i]){
//             $mini = $array[$i];
//         }
//     }
//     return $mini;
// }

// $result = mini($tab);

// var_dump($result);



$tab = [10,20,30,423,5];

function maxe(Array $array){
    $maxe = $array[0];
    for($i = 0;$i < count($array);$i++){
        if($maxe < $array[$i]){
            $maxe = $array[$i];
        }
    }
    return $maxe;
}

$result = maxe($tab);

var_dump($result);