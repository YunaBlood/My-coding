<?php

namespace App\Controller;

use \App\Model\FilmModel;

class FilmController extends Controller {
    
    public function show(){
        $films = FilmModel::getFilms();

        $this->render('films', ['films' => $films]);
    }

    public function getFilm($id){
        //Peut être des contrôles...
        $film = FilmModel::getFilmById($id);

        if(!$film){
            $this->redirect('not_found');
        }

        $this->render('film', ['film' => $film]);
    }
}