<div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-6">
                <div class="box">
                    <h3 class="mb-0"><?= ucfirst($film->titre) ?></h3>
                    <hr>
                    <p><span class="bold">Date de sortie : </span><?= $film->date_sortie ?></p>
                    <p><span class="bold">Synopsis :</span><br><?= $film->synopsis ?></p>
                </div>
            </div>
        </div>
    </div>

