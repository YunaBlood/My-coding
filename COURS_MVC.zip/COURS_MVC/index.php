<?php
session_start();

// Constante d'environnement
define('ROOT', __DIR__);
define('PATH_URL', '/COURS_MVC');
// Importer l'autoloader
require_once('./vendor/autoload.php');
//Création du routeur
$router = new \Bramus\Router\Router();

// Table de routage
$router->get('/film','\App\Controller\FilmController@show');
$router->get('/film/(\d+)', '\App\Controller\FilmController@getFilm');

$router->get('/portfolio', function(){
    echo "Bienvenue sur mon portfolio";
});

$router->run();