<?php

session_start();

$_SESSION['verification'] = "";

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Connexion</title>
    <link rel="stylesheet" type="text/css" href="Semantic-UI-CSS-master/semantic.min.css">
<script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous">
  $('.message .close')
  .on('click', function() {
    $(this)
      .closest('.message')
      .transition('fade')
    ;
  })
;
</script>
<script src="Semantic-UI-CSS-master/semantic.min.js"></script>
<link rel="stylesheet" href="Connexion.css">

</head>
<body>

<form method="POST" action="postconnexion.php">
<img class="ui centered circular image" src="image/téléchargement.png">
    <div class="ui middle aligned center aligned grid">
  <div class="column">
  <div class="ui stacked segment">
        <div class="field">
          <div class="ui left icon input">
            <i class="user icon"></i>
            <input id="email" type="text" name="email" placeholder="E-mail address">
          </div>
      </div>
      <div class="field">
          <div class="ui left icon input">
            <i class="lock icon"></i>
            <input id="password" type="password" name="password" placeholder="Password">
          </div>
          <?php if(isset($_SESSION['error'])):?>
          <div class="ui error message"><?= $_SESSION['error']?></div>
        <?php endif; ?>
        <?php if(isset($_SESSION['confirm'])):?>
          <div class="confirm"><?= $_SESSION['confirm']?></div>
        <?php endif; ?>
      </div>
      <div>
          <button type="submit" class="ui fluid large submit button">Se connecter</button>
      </div>
    </div>
  </div>
  </div>
</form>

      <?php $_SESSION['error'] = "" ?>
    <?php $_SESSION['confirm'] = "" ?>
</body>
</html>