<?php

session_start();

if($_SESSION['verification']!="verif"){
    
    $_SESSION['error'] = "Redirection vers la page de connexion !";
    header('Location: connexion.php');
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Calendrier</title>
    <link rel="stylesheet" type="text/css" href="../Semantic-UI-CSS-master/Semantic-UI-CSS-master/semantic.min.css">
<script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
    <script src="Semantic-UI-CSS-master/semantic.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../Semantic-UI-CSS-master/semantic.min.css">
  </head>

<body>
<div class="ui main text container">
    <h1 class="ui header centered">Choisisez votre Date</h1>
    <p>Sélectionner votre date puis validez !</p>
</div>


<script>
var today = new Date();
 $('#minmax_calendar')
  .calendar({
    minDate: new Date(today.getFullYear(), today.getMonth(), today.getDate() - 5),
    maxDate: new Date(today.getFullYear(), today.getMonth(), today.getDate() + 5)
  })
;
</script>
<div class="ui calendar centered" id="minmax_calendar">
  <div class="ui input left icon">
    <i class="calendar icon"></i>
    <input type="text" placeholder="Date">
  </div>
</div>




  <div class="ui large submit button "><a href="../dashboard/DashBoard.php">Validez </div>

    
</body>
</html>