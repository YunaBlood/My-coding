<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Profil</title>
    <script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
<script src="../Semantic-UI-CSS-master/semantic.min.js"></script>
<link rel="stylesheet" type="text/css" href="../Semantic-UI-CSS-master/semantic.min.css">
<link rel="stylesheet" href="Profil.css">

</head>
<body>
<script> 
 $(document)
    .ready(function() {

      // fix main menu to page on passing
      $('.main.menu').visibility({
        type: 'fixed'
      });
      $('.overlay').visibility({
        type: 'fixed',
        offset: 80
      });

      // lazy load images
      $('.image').visibility({
        type: 'image',
        transition: 'vertical flip in',
        duration: 500
      });

      // show dropdown on hover
      $('.main.menu  .ui.dropdown').dropdown({
        on: 'hover'
      });
    })
  ;
</script>
<div class="ui main text container">
    <h1 class="ui header centered">Profil</h1>
    <!-- Profil employeur -->
    <p>Suivis</p>
</div>


<div id="test" class="ui borderless main menu">
    <div class="ui text container">
      <div class="header item">
      <i class="home icon"></i>
        <a href="DashBoard.php" class="item">Acceuil</a>   
        
        <!-- Renvois soit vers employer soit admin -->
      </div>
        </div>
      </a>
    </div>
</div>

<div class="ui four link cards centered">
    <div class="card">
        <div class="image">
            <img src="LOLOLO.jpg">
        </div>
    <div class="content">
        <div class="header">Matt Giampietro</div>
            
        <div class="description">
            43000 km - Fiat - MULTIPLA
        </div>
        
    </div>
    </div>
</div>


<div class="ui form centered">
    <div class="field">
        <label>Merci d'indiqué le suivis du véhicule ci-dessous</label>
        <textarea ></textarea>
    <div class="ui segment">
        <button class="ui black basic button">Basic Black</button>
    </div>
    </div>
</div>




</body>
</html>