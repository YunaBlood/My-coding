<?php

session_start();
    // Verification si les champs sont vides 
if(!isset($_POST['email']) || !isset($_POST['password']) || empty($_POST['email']) || empty($_POST['password'])){
    $_SESSION['error'] = "Certains champs sont vides";
    header('Location: connexion.php');
    exit();
}

$_SESSION['error']="";
$email = htmlspecialchars($_POST['email']);
$password = htmlspecialchars($_POST['password']);

// Nouvelle connexion a la base de données
$db = new PDO('mysql:host=localhost; dbname=parcauto; charset=utf8;','root',NULL);
// Affichage des erreurs SQL
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$test_email = 'SELECT password FROM utilisateur WHERE email =:email';

$requete = $db->prepare($test_email);
$requete->execute([':email'=>$email]);
$id_email = $requete->fetch(PDO::FETCH_ASSOC);

if(password_verify($_POST['password'], $id_email['password'])){
    $_SESSION['verification']="verif";
    header('location: calendar.php');
    exit;
}else{
    header('Location: connexion.php');
    $_SESSION['error'] = "Certains champs sont incorrects !";
    exit();
}
    
var_dump($_POST);
?>