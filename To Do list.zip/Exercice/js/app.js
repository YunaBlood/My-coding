const boxes = document.getElementById('boxes--container')
const boxes2 = document.querySelectorAll('.box')
const divs = document.getElementsByTagName('div')
const classBox = document.getElementsByClassName('box')


boxes2.forEach( box => {
    console.log(box)
    box.addEventListener('click', () =>{
        box.setAttribute('data-show','remove')
        setTimeout(() => {
            box.remove()
        },350);

    })
})

const submit = document.getElementById('submit')

submit.addEventListener('click', event => {
    event.preventDefault()
    const task = document.getElementById('task').value
   

    
    if(task !== ''){
         const newDiv = document.createElement('div')
    
        newDiv.className = ('box')
        newDiv.setAttribute('data-show','')
        newDiv.innerHTML = task
        

        newDiv.addEventListener('click', () =>{
            newDiv.setAttribute('data-show','remove')
            setTimeout(() =>{
                newDiv.remove()
            },350);
        })
        
        boxes.appendChild(newDiv)
    }
    
})

